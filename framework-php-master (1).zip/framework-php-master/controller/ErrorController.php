<?php

function index()
{
	echo "Uhmm, durp, een error! 404 ofzo?";
}